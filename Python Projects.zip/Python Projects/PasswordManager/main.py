from tkinter import *
from tkinter import messagebox
from random import randint, choice, shuffle
import json
#install pyperclip to enjoy clipboard automatic copy functionality
# import pyperclip

# ---------------------------- PASSWORD GENERATOR ------------------------------- #
def generate_password():
    '''Generate Password'''
    letters =  ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
                'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 'y',
                'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D',
                'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
                'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
                'Y', 'Z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

    password_letters = [choice(letters) for _ in range(randint(8, 10))]
    password_symbols = [choice(symbols) for _ in range(randint(2, 4))]
    password_numbers = [choice(numbers) for _ in range(randint(2, 4))]

    password_list = password_letters + password_symbols + password_numbers

    shuffle(password_list)

    password = "".join(password_list)

    if len(password_entry.get()) == 0:
        password_entry.insert(0, password)
        # pyperclip.copy(password)

# ---------------------------- SAVE PASSWORD ------------------------------- #

def save():
    website = website_entry.get()
    email = email_entry.get()
    password = password_entry.get()
    new_data = {
        website: {
            'email/username': email,
            'password': password
        }
    }

    if len(password) == 0 or len(website) == 0:
        messagebox.showinfo(title='Oops', message='Please make sure you haven\'t left any fields empty')
    else:
        # # Update (This commented code change to JSON file)
        # is_ok_to_save = messagebox.askokcancel(title=website, message='These are the details entered: \n'
        #                                    f'Email: {email} \nPassword: {password} \nIs ok to save?')
        
        # if is_ok_to_save:
            # write the data in the local data file
        try:
            with open('data.json', 'r') as data_file:
                # data_file.write(f'Website: {website} | Email: {email} | Password: {password}\n')
                #Readind Old data
                data = json.load(data_file)
        except FileNotFoundError:
            with open('data.json', 'w') as data_file:
                json.dump(new_data, data_file, indent=4)
        else:
            # update the old data with new data
            data.update(new_data)

            #Saving Updated data
            with open('data.json', 'w') as data_file:
                json.dump(data, data_file, indent=4)
        finally:
            website_entry.delete(0, END)
            password_entry.delete(0, END)

# ---------------------------- SEARCH ------------------------------- #

def search():
    '''Serch to find password if it does exist in the json file'''
    website = website_entry.get()
    try:
        with open('data.json', 'r') as data_file:
            data = json.load(data_file)
    except FileExistsError:
        messagebox.showinfo(title="Error", message='No Data File Found.')
    else:
        if website in data:
            email = data[website]['email/username']
            password = data[website]['password']
            messagebox.showinfo(title=website, message=f"Email/Username: {email}\nPassword: {password}")
        else:
            messagebox.showinfo(title="Error", message=f"No details for {website} exists.")

# ---------------------------- BUTTONS ------------------------------- #
# Function to change button color on hover
def on_enter(e):
    e.widget.config(bg="#1565C0")  # Darker blue on hover

def on_leave(e):
    e.widget.config(bg="#1976D2")  # Original blue

# ---------------------------- UI SETUP ------------------------------- #

windows = Tk()
windows.title('Passowrd Manager')
windows.config(padx=20, pady=20, bg="#E8F0FE")

canvas = Canvas(height=200, width=200, bg="#E8F0FE", highlightthickness=0)
logo_img = PhotoImage(file='logo.png')
canvas.create_image(100, 100, image=logo_img)
canvas.grid(row=0, column=1)

# Colors & Font
LABEL_COLOR = "#1A237E"  # Dark blue
ENTRY_BG = "#FFF9C4"  # Light yellow
BUTTON_BG = "#1976D2"  # Blue
BUTTON_FG = "white"  # White text
FONT = ("Arial", 10, "bold")

#Labels
website_label = Label(text='Website:', font=FONT, fg=LABEL_COLOR, bg="#E8F0FE")
website_label.grid(row=1, column=0)

email_label = Label(text='Email/Username:', font=FONT, fg=LABEL_COLOR, bg="#E8F0FE")
email_label.grid(row=2, column=0)

password_label = Label(text='Password:', font=FONT, fg=LABEL_COLOR, bg="#E8F0FE")
password_label.grid(row=3, column=0)

#Entry
website_entry = Entry(width=21, font=FONT, bg=ENTRY_BG, relief=FLAT, borderwidth=3)
website_entry.grid(row=1, column=1, padx=5, pady=5)
website_entry.focus()

email_entry = Entry(width=35, font=FONT, bg=ENTRY_BG, relief=FLAT, borderwidth=3)
email_entry.grid(row=2, column=1, columnspan=2)
email_entry.insert(0, 'alaminhnab4@gmail.com')

password_entry = Entry(width=21, font=FONT, bg=ENTRY_BG, relief=FLAT, borderwidth=4)
password_entry.grid(row=3, column=1, padx=5, pady=5)

# Custom Button Style
button_style = {"font": FONT, "fg": BUTTON_FG, "bg": BUTTON_BG, 
                "borderwidth": 0, "relief": FLAT, "padx": 10, "pady": 5}

# Buttons
generate_password_button = Button(text='Generate\n Password', command=generate_password,
                                  **button_style, width=12)
generate_password_button.grid(row=3, column=2, padx=5, pady=5)
generate_password_button.bind("<Enter>", on_enter)
generate_password_button.bind("<Leave>", on_leave)

add_button = Button(text='Add', width=36, command=save,
                    **button_style,)
add_button.grid(row=4, column=1, columnspan=2, padx=5, pady=5)
add_button.bind("<Enter>", on_enter)
add_button.bind("<Leave>", on_leave)

search_button = Button(text='Search', width=13, command=search,
                       **button_style,)
search_button.grid(row=1, column=2, padx=5, pady=5)
search_button.bind("<Enter>", on_enter)
search_button.bind("<Leave>", on_leave)

windows.mainloop()