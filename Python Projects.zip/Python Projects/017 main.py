# print("Welcome to the Band Name Generator.")
# street = input("What's the name of the city you grew up in?\n")
# pet = input("What's your pet's name?\n")
# print("Your band name could be " + street + " " + pet)


# tip calculator
# print("Welcome to the tip Calcutor!")
# bill = float(input("What was the total bill? $"))
# tip = int(input("How much tip would you like to pay? 10, 20, or 15? "))
# people = int(input("How many people to split the bill? "))
# tip_as_percent = tip/100
# bill_to_pay_per_person = ((bill/people)* (1 + tip_as_percent))
# final_amount = "{:.2f}".format(bill_to_pay_per_person)
# print(f"Each person should pay: ${final_amount}")

# Day 16. 
## Object Oriented Programming(OOP)

# from turtle import Turtle, Screen

# timmy = Turtle()
# print(timmy)
# timmy.shape('turtle')
# timmy.color('red', 'blue')
# timmy.forward(100)

# my_screen = Screen()
# print(my_screen)
# print(my_screen.canvheight)
# my_screen.exitonclick()

# Password Generator Project

# import random

# letters =  ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
#             'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 'y',
#             'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D',
#             'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
#             'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
#             'Y', 'Z']

# numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
# symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

# print("Welcome to Password Generator!")
# nr_letters = int(input("How many letters would you like in your Passwors? \n"))
# nr_symbol = int(input("How many symbols would you like? \n"))
# nr_numbers = int(input("How many numbers would you like? \n"))

# Easy Level:
# password = ""

# for char in range(1, nr_letters+1):
#     password += random.choice(letters)

# for char in range(1, nr_symbol+1):
#     password += random.choice(symbols)

# for char in range(1, nr_numbers+1):
#     password += random.choice(numbers)

# print(f"Your Generated Password is: {password}")

# import random
# import os
# from hangman_words import word_list
# from hangman_art import logo

# chosen_word = random.choice(word_list)
# word_length = len(chosen_word)

# end_of_game = False
# lives = 6
# print(logo)

# # print(f'Pssst, the solution is {chosen_word}.')

# #Create blanks
# display = []
# for _ in range(word_length):
#     display += "_"

# while not end_of_game:
#     guess = input("Guess a letter: ").lower()

#     # If the user has entered a letter they've already guessed, print the letter and let them know.
#     if guess in display:
#         print(f"You've already guessed {guess}")

#     #Check guessed letter
#     for position in range(word_length):
#         letter = chosen_word[position]
#         #print(f"Current position: {position}\n Current letter: {letter}\n Guessed letter: {guess}")
#         if letter == guess:
#             display[position] = letter

#     #Check if user is wrong.
#     if guess not in chosen_word:
#         # If the letter is not in the chosen_word, print out the letter and let them know it's not in the word.
#         print(f"You guessed {guess}, that's not in the word. You lose a life.")
        
#         lives -= 1
#         if lives == 0:
#             end_of_game = True
#             print("You lose.")

#     #Join all the elements in the list and turn it into a String.
#     # os.system('cls') clear the screen
#     print(f"{' '.join(display)}")

#     #Check if user has got all letters.
#     if "_" not in display:
#         end_of_game = True
#         print("You win.")

#     from hangman_art import stages
#     print(stages[lives])
#     # print('\033[H\033[J', end='') clear the screen
#     print('\033[H\033[J', end='')

# # Project: Calculator
# from os import system
# from arts import cal_logo

# # Add
# def add(n1, n2):
#     '''Return the addition value of the first & second digit: e.g 4+3 = 7'''
#     return n1+n2

# # Subtract
# def subtract(n1, n2):
#     '''Return the subtraction value of the first & second digit: e.g 4-3 = 1'''
#     return n1-n2

# # Multiply
# def multiply(n1, n2):
#     '''Return the multiplication value of the first & second digit: e.g 4*3 = 12'''
#     return n1*n2

# # Divide
# def divide(n1, n2):
#     '''Return the division value of the first & second digit: e.g 4/3 = 1.333'''
#     return n1/n2

# # Operation Dict
# operations = {
#     '+': add,
#     '-': subtract,
#     '*': multiply,
#     '/': divide
# }

# def calculator():
#     print(cal_logo)
#     # Numbers
#     num1 = float(input("What's the first number?: "))

#     # Loop through the operation dict
#     for opp in operations:
#         print(opp)

#     start_calcution = True
#     end_calculation = False
#     while start_calcution:
#         operation_symbol = input("Pick an operation: ")
#         num2 = float(input("What's the next number?: "))

#         calculation_function = operations[operation_symbol]
#         answer = calculation_function(num1, num2)
#         print(f"{num1} {operation_symbol} {num2} = {answer}")
#         user_option = input(f"Type 'yes' to continue calculation with {answer} or type 'no' to start a new calculation.\nPress any key to exit.").lower()

#         if user_option == 'yes':
#             num1 = answer
#         elif user_option == 'no':
#             start_calcution = end_calculation
#             system('cls')
#             calculator()
#         else:
#             start_calcution = end_calculation

# calculator()

# Day 18.
# from turtle import Turtle, Screen
# import random
# import turtle

# tim = Turtle()
# color = ['CornflowerBlue', 'DarkOrchid', 'DeepSkyBlue', 'indianred', 'wheat', 'SlateGray', 'LightSeaGreen', 'SeaGreen']
# # directions = [0, 90, 180, 270]
# tim.speed('fastest')
# # tim.width(8)
# turtle.colormode(255)

# def random_color():
#     r = random.randint(0, 255)
#     g = random.randint(0, 255)
#     b = random.randint(0, 255)
#     random_c = (r, g, b)
#     return random_c

# for t in range(200):
#     tim.color(random_color())
#     tim.forward(30)
#     tim.setheading(random.choice(directions))


# for i in range(4):
#     tim.forward(100)
#     tim.right(90)

# for i in range(15):
#     tim.forward(10)
#     tim.penup()
#     tim.forward(10)
#     tim.pendown()


# def draw_shape(n_side):
#     angel = 360/n_side
#     for i in range(n_side):
#         tim.forward(100)
#         tim.right(angel)


# for number_of_side in range(3, 11):
#     tim.color(random.choice(color))
#     draw_shape(number_of_side)


# screen = Screen()
# screen.exitonclick()

# Day 18. 
#  Turtle Projects

import turtle as t
import random

tim = t.Turtle()
tim.speed('fastest')
t.colormode(255)

def gen_rgb_colors():
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    random_color = (r, g, b)
    return random_color

def draw_spirograph(size_of_gap):
    for i in range(int(360 / size_of_gap)):
        tim.color(gen_rgb_colors())
        tim.circle(100)
        tim.setheading(tim.heading() + 10)

draw_spirograph(5)


screen = t.Screen()
screen.exitonclick()