path = '/Users/Dsct.Engr.Al-amin/Desktop/working_env/Projects_Base/Python Projects/Mail-Merges-Project/Input/Names/invited_names.txt'
letter_to_send_path = '/Users/Dsct.Engr.Al-amin/Desktop/working_env/Projects_Base/Python Projects/Mail-Merges-Project/Input/Letters/starting_letter.txt'
PLACE_HOLDER = '[name]'

with open(path) as name_list:
    names = name_list.readlines()
    # print(names)

letter_path = '/Users/Dsct.Engr.Al-amin/Desktop/working_env/Projects_Base/Python Projects/Mail-Merges-Project/Output/ReadyToSend/'

with open(letter_to_send_path) as completed_letter:
    letter_file = completed_letter.read()
    for name in names:
        nam_ = name.strip()
        new_letter = letter_file.replace(PLACE_HOLDER, nam_)
        with open(f'/Users/Dsct.Engr.Al-amin/Desktop/working_env/Projects_Base/Python Projects/Mail-Merges-Project/Output/ReadyToSend/letter_for_{nam_}.txt', mode='w') as send_letter:
           send_letter.write(new_letter)