from turtle import Turtle
FONT = ('Courier', 24, 'normal')
ALIGNMENT = 'center'
data_path = '/Users/Dsct.Engr.Al-amin/Desktop/working_env/Projects_Base/Python Projects/snake_game/data.txt'
path = '../../../Desktop/data.txt'

class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.score = 0
        # Update(read our high score from data.txt file)
        # self.high_score = 0
        with open(data_path) as data:
            self.high_score = int(data.read())
        self.penup()
        self.color('white')
        self.hideturtle()
        self.goto(0, 265)
        self.update_score()

    # # Update(method read our high score from data.txt file.)
    # def read_score(self):
    #     with open('./snake_game/data.txt', mode='r') as score_data:
    #         high_score = score_data.read()
    #         print(high_score)

    # # Update(method to write new high score in data.txt file.)
    # def write_score(self):
    #     with open('./snake_game/data.txt', mode='w') as score_data:
    #         high_score = score_data.read()
    #         print(high_score)

    def update_score(self):
        self.clear()
        self.write(f'Score: {self.score} High Score: {self.high_score}', align=ALIGNMENT, font=FONT)

    def reset(self):
        if self.score > self.high_score:
            self.high_score = self.score
            with open(data_path, mode='w') as data:
                data.write(f"{self.high_score}")

        self.score = 0
        # self.high_score = self.write_score()
        self.update_score()

    # def game_over(self):
    #     self.goto(0, 0)
    #     self.write(f'GAME OVER😭🐍!', align=ALIGNMENT, font=FONT)
    #     self.goto(0, -280)
    #     self.write(f'Programmed by: Engr.Al-amin H Nababa', align=ALIGNMENT, font=('Courier', 8, 'italic'))
        
    def increase_score(self):
        self.score += 1
        self.clear()
        self.update_score()