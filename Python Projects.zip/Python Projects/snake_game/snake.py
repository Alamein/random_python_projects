from turtle import Turtle

STARTING_POSITION = [(0, 0), (-20, 0), (-40, 0)]
MOVE_DISTANCE = 20
UP = 90
DOWN = 270
LEFT = 180
RIGHT = 0

class Snake(Turtle):
    
    def __init__(self):
        super().__init__()
        self.segments = []
        self.create_snake()
        self.head = self.segments[0]

    def create_snake(self):
        for snake in STARTING_POSITION:
            self.add_segment(snake)
            # snake_2 = Turtle(shape='square')
            # snake_2.color('white')
            # snake_2.penup()
            # snake_2.goto(-20, 0)

            # snake_3 = Turtle(shape='square')
            # snake_3.color('white')
            # snake_3.penup()
            # snake_3.goto(-40, 0)

    def add_segment(self, position):
        g_snake = Turtle(shape='square')
        # snake_1.shape('square')
        g_snake.color('white')
        #g_snake.shapesize(stretch_wid=0.2, stretch_len=1) #try this shapesize(stretch_wid=0.2, stretch_len=0.2)
        g_snake.penup()
        g_snake.goto(position)
        self.segments.append(g_snake)

    def reset(self):
        for seg in self.segments:
            seg.goto(1000, 1000)
        self.segments.clear()
        self.create_snake()
        self.head = self.segments[0]

    def extend(self):
        self.add_segment(self.segments[-1].position())

    def move(self):
        for seg_num in range(len(self.segments)-1, 0, -1):
            # seg.forward(20)
            new_x = self.segments[seg_num - 1].xcor()
            new_Y = self.segments[seg_num - 1].ycor()
            self.segments[seg_num].goto(new_x, new_Y)
        self.head.forward(MOVE_DISTANCE)

    def up(self):
        if self.head.heading() != DOWN:
            self.head.setheading(UP)

    def down(self):
        if self.head.heading() != UP:
            self.head.setheading(DOWN)

    def left(self):
        if self.head.heading() != RIGHT:
            self.head.setheading(LEFT)

    def right(self):
        if self.head.heading() != LEFT:
            self.head.setheading(RIGHT)

        
    