import datetime as dt
import pandas as pd
import random
import smtplib

# get today's date
today = (dt.datetime.now().month, dt.datetime.now().day)
# print(today)

# read csv
data = pd.read_csv('birthdays.csv')
# print(data)
birthday_dict = {(data_row.month, data_row.day): data_row for (index, data_row) in data.iterrows()}

#mail details
MY_EMAIL = 'alaminnababa@gmail.com'
MY_PASSWORD = 'alalalaalal'

# check
if today in birthday_dict:
    birthday_person = birthday_dict[today]
    file_path = f'./letter_templates/letter_{random.randint(1, 3)}.txt'
    with open(file_path) as file:
        content = file.read()
        # print(content)
        file_to_share = content.replace('[NAME]', birthday_person['name'])
    
    # send to an email
    with smtplib.SMTP('smtp.gmail.com') as connection:
        connection.starttls()
        connection.login(user=MY_EMAIL, password=MY_PASSWORD)
        connection.sendmail(from_addr=MY_EMAIL, 
                            to_addrs=birthday_person['email'],
                            msg=f"Subject: HAPPY BIRTHDAY\n\n\{file_to_share}")
        

        # To host your code use this link: https://www.pythonanywhere.com/
        