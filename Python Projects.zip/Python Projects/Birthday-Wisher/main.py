# SMTP stand for: Simple Mail Transfer Protocol
# import smtplib to start working with SMTP withing our python code

# SMTP Setup for diffrent mail proveders:
    # Email: smtp.gmail.com
    # Yahoo: smtp.mail.yahoo.com
    # Hotmail: smtp.live.com
    # Other: Search google, search stackoverflow, or ask one of the LLMs out there.

# import smtplib

# # mail address
# my_email = 'geekhacker44@gmail.com'
# # login password
# # You need to have an app password from google server before doing this. Otherwise you will get an error
# l_p_s = 'GeekHacker@234'

# # try with () as x, to avoid using .close() at the end of our code
# with smtplib.SMTP('smtp.gmail.com') as connection:
#     connection.starttls()
#     connection.login(user=my_email, password=l_p_s)
#     connection.sendmail(from_addr=my_email, 
#                         to_addrs='alaminnababa81@gmail.com',
#                         msg=('Subject: Testing\n\nThis is just a testing message'))
# Make a connection
# connection = smtplib.SMTP("smtp.gmail.com")
# connection.starttls() # starttls meaning start transfer layer security(block third party access)
# connection.login(user=my_email, password=l_p_s)

# # send message
# connection.sendmail(from_addr=my_email, 
#                     to_addrs='alaminnababa81@gmail.com', 
#                     msg=('Subject: Testing\n\nThis is just a testing message'))

# close connection
# connection.close() # with () as x: can be work to avoid using .close()


# # Datetime Module
# import datetime as dt

# now = dt.datetime.now()
# print(now)




import smtplib
import datetime as dt
import random

MY_EMAIL = 'geekhacker44@gmail.com'
MY_PASSWORD = '1234fgdf'

now = dt.datetime.now()
week_day = now.weekday()
if week_day == 0:
    with open('quotes.text') as quote_file:
        all_quote = quote_file.readline()
        quote = random.choice(all_quote)
    print(quote)
    with smtplib.SMTP('smtp.gmail.com') as connection:
        connection.login(user=MY_EMAIL, password=MY_PASSWORD)
        connection.starttls()
        connection.sendmail(from_addr=MY_EMAIL, 
                            to_addrs='alaminnababa@gmail.com',
                            msg=f'Subject:Monday Motivition\n\n{quote}'
                            )
