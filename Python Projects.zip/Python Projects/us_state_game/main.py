# # import pandas as pd

# # data = pd.read_csv('/Users/Dsct.Engr.Al-amin/Desktop/working_env/Projects_Base/Python Projects/day_25/weather_data.csv')
# # print(data.head())

# path = '/Users/Dsct.Engr.Al-amin/Desktop/working_env/Projects_Base/Python Projects/day_25/weather_data.csv'

# # with open(path) as data:
# #     weather_data = data.readlines()
# #     print(weather_data)

# # import csv
# # with open(path) as data_file:
# #     data = csv.reader(data_file)
# #     temperature = []
# #     for row in data:
# #         # print(row)
# #         if row[1] != 'temp':
# #             temperature.append(int(row[1]))
# #     print(temperature)

# import pandas as pd
# data = pd.read_csv(path)
# print(data['temp'].mean())
# print(data['temp'].max())
# print(data[data['temp'] == data['temp'].max()])


#    Allof the above are short things to remember for day 25 lesson

import turtle

screen = turtle.Screen()
screen.title('U.S States game')
img = '/Users/Dsct.Engr.Al-amin/Desktop/working_env/Projects_Base/Python Projects/us_state_game/blank_states_img.gif'
screen.addshape(img)
turtle.shape(img)

import pandas as pd
states_data_path = '/Users/Dsct.Engr.Al-amin/Desktop/working_env/Projects_Base/Python Projects/us_state_game/50_states.csv'
data = pd.read_csv(states_data_path)
# print(data.head())

score = 0
# screen.title('State Correct')
states = data['state'].to_list()

# position = turtle.Turtle()
# position.shape('circle')
# position.color('white')
# position.shapesize(stretch_wid= 2, stretch_len=2)
correct_gues = []
while len(correct_gues) < 50:
    answer_state = screen.textinput(title=f'{score}/50 State Correct', 
                                    prompt='Type another state here').title()
    if answer_state == 'Exit':
        missing_state = [state for state in states if state not in correct_gues]
        # for state in states:
        #     if state not in correct_gues:
        #         missing_state.append(state)
        new_data = pd.DataFrame(missing_state)
        new_data.to_csv(
            '/Users/Dsct.Engr.Al-amin/Desktop/working_env/Projects_Base/Python Projects/us_state_game/right_guess.csv'
        )
        break
    if answer_state in states:
        score += 1
        correct_gues.append(answer_state)
        # screen.title(f'Correct States: {score}/{len(states)}')
        t = turtle.Turtle()
        t.hideturtle()
        t.penup()
        state_data = data[data.state == answer_state]
        t.goto(int(state_data.x), int(state_data.y))
        t.write(answer_state)
        # if answer_state in correct_gues:
        #     score = score

# screen.exitonclick()
